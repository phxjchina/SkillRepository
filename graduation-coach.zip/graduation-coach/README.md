# graduation-coach · 毕业设计辅导教练（学生端专家包）

面向**普通本科高校本科生**的一对一毕业设计全程陪跑教练。内嵌技能 [`graduation-design-coach`](./skills/graduation-design-coach/)。

- **七阶段**：选题 → 配合任务书 → 开题报告 → 工程实施 → 中期检查 → 论文撰写 → 答辩准备
- **每步产出自检**：必改/建议两级清单，闸门不达标不放行
- **脚手架**：任务书/开题/论文可填空骨架(.docx) + 答辩PPT(.pptx)
- **边界**：只辅导不代写
- 配套教师端专家包：`graduation-supervisor`（监督导师，共享五条跨文档铁律）
